#include<stdio.h>
#include <stdlib.h>
int swap(int array[], int *a, int *b){
	int temp = *a;
	*a = *b;
	*b = temp;
	return 0;
}

int linear_search(int array[], int size, int target){
	for(int i = 0; i < size ; i++){
		if(target == array[i]){
			printf("Target found at %d index.",i);
			return i;
		}
	}
	printf("Target not found.");
	return -1;
}

int binary_search(int array[] , int size, int target){
	int low , mid, high;
	low = 0;
	high = size -1;
	while(high >= low){
		mid = (high+low)/2;
		if(array[mid] == target){
			printf(
			return mid;
}

void bubble_sort(int array[] ,int size){
		int i , j ;
		for(i = 0 ; i < size; i++){
			for(j = 0; j< size-1-i; j++){
				if(array[j] > array[j+1]){
					swap(array, &array[j], &array[j+1]);
				}
			}
		}
}



int main(){
	int n, target, ch, i ,j , k;

	printf("1- Linear Search\n");
	printf("2- Binary Search\n");
	printf("3- Insertion Sort\n");
	printf("4- Bubble Sort\n");
	printf("5- Slection Sort\n");
	printf("Enter Choice:");
	scanf("%d", &ch);
	if(ch == 1 || ch ==2){
		printf("Enter the number of elements of the array to be generated:");
		scanf("%d",&n);
		int array[n];
		for(i = 0; i <n;i++){
			printf("Enter the %d element",i);
			scanf("%d",&array[i]);
		}

		//printing the array
		for(j = 0; j <n ;j++){
			printf("%d ",array[j]);
		}

		//taking target
		printf("\nEnter the target to find :");
		scanf("%d",&target);
		
		if(ch == 1){
			linear_search(array, n , target);
		}
		else{
			binary_search(array, n , target);
		}
	}
	else if(ch == 4){
	
		printf("Enter the number of elements of the array to be generated:");
		scanf("%d",&n);
		int array[n];
		// making array with random numbers from 1-100
		for(i = 0 ; i < n ;i++){
			array[i] = rand() %100 +1;
		}
		
		//printing the array
		for(j = 0; j <n ;j++){
			printf("%d ",array[j]);
		}
		
		//sorting
		bubble_sort(array , n);

		
		printf("\n Printing after Bubble sort\n");
		//printing the array after bubble sort
		for(j = 0; j <n ;j++){
			printf("%d ",array[j]);
		}
	}
}


`
